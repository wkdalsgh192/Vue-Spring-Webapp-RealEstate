<template>
  <div id="app">
    <nav-header></nav-header>
    <h2 class="text-center"></h2>
    <router-view></router-view>
    <br>
    <br>
    <nav-footer></nav-footer>
  </div>
</template>

<script>
import NavHeader from './layout/Header.vue';
import NavFooter from './layout/Footer.vue';
export default {
  name: 'App',
  components: {
    NavHeader,
    NavFooter,
  },
};
</script>


