<template>
  <div>
    <br><br><br>
    <h2 class="text-center" style="font-family : 'Black Han Sans'"> 글 상세 내용 </h2>
    <table class="table table-bordered w-50">
      <tr>
        <th>No.</th>
        <td>{{ no }}</td>
      </tr>
      <tr>
        <th>Writer</th>
        <td>{{ writer }}</td>
      </tr>
      <tr>
        <th>Title</th>
        <td>{{ title }}</td>
      </tr>
      <tr>
        <th>Registration Date</th>
        <td>{{ getFormatDate(regtime) }}</td>
      </tr>
      <tr>
        <td colspan="2">
          {{ content }}
        </td>
      </tr>
    </table>

    <br />
    <div class="text-center">
      <router-link to="/list"
        ><button class="btn btn-primary" style = "background-color : #5c6bc0" >목록</button></router-link
      >
      <router-link :to="'/update?no=' + no"
        ><button class="btn btn-primary" style = "background-color : #5c6bc0" >수정</button></router-link
      >
      <router-link :to="'/delete?no=' + no"
        ><button class="btn btn-primary" style = "background-color : #5c6bc0" >삭제</button></router-link
      >
    </div>
  </div>
</template>

<script>
import moment from 'moment';
export default {
  name: 'detail',
  props: {
    no: { type: Number },
    writer: { type: String },
    title: { type: String },
    content: { type: String },
    regtime: { type: String },
  },
  methods: {
    getFormatDate(regtime) {
      return moment(new Date(regtime)).format('YYYY.MM.DD HH:mm:ss');
    },
  },
};
</script>
