<template>
  <div>
    <v-app-bar
      absolute dark
      color="yellow"
      src="https://picsum.photos/1920/1080?random"
      style = "height : 100px"
    >
      <v-app-bar-nav-icon></v-app-bar-nav-icon>

      <v-toolbar-title><router-link to='/'>HappyHouse</router-link></v-toolbar-title>
      
      <v-spacer></v-spacer>
      <v-btn :to="{ name : 'create'}"> 등록 </v-btn>
      <v-btn :to="{name: 'list'}"> 리스트 </v-btn>
      <v-btn :to="{name: 'list'}"> 동별 검색 </v-btn>
      <v-btn :to="{name: 'list'}"> 아파트 검색 </v-btn>
      <v-btn :to="{name: 'list'}"> 로그아웃 </v-btn>
      <v-btn icon>
        <v-icon>mdi-magnify</v-icon>
      </v-btn>

      <v-btn icon>
        <v-icon>mdi-heart</v-icon>
      </v-btn>

      <v-btn icon>
        <v-icon>mdi-dots-vertical</v-icon>
      </v-btn>
    </v-app-bar>
    <br>
    <br>
    <br>
  </div>
</template>

<script>
export default {
  name: 'AppHeader',
};
</script>

<style>
  .router-link-active{
    color: white;
  }
  .router.link-exact-active{
    color: white;
  }
</style>
