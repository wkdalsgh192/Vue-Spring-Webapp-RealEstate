<template>
  <div>
    <div>
      <br><br><br>
      <h1 class="text-center" style="font-family : 'Black Han Sans'">어떤 동네, 어떤 아파트에서 <br> 살고 싶으신가요?</h1>
      <br>
      <v-divider></v-divider>
      <br>
      <h3 class="text-center" style="Nanum Gothic">Happy house 에서는 <br> 이런기능들을 제공합니다.</h3>
    <br><br>
   
    <v-card >
    <v-tabs
      v-model="tab"
      grow
    >
      <v-tab
        v-for="item in items"
        :key="item.tab"
        style = "font-size:25px"
      >
        {{ item.tab }}
      </v-tab>
    </v-tabs>

    <v-tabs-items v-model="tab">
      <v-tab-item
        v-for="item in items"
        :key="item"
      >
        <v-card
          flat
        >
          <v-card-text style = "font-size:20px">{{ item.content }}</v-card-text>
        </v-card>
      </v-tab-item>
    </v-tabs-items>
  </v-card>
  <br><br>
    </div>
  </div>
</template>

<script>
export default {
  name: "index",
  components: {}
};
</script>
<script>
  export default {
    data () {
      return {
        tab: null,
        items: [
          { tab: '동별 매물 정보 검색', content: '시도, 구, 동을 선택하면 해당하는 지역에 매물 정보를 알 수 있습니다.(지도를 통해 보다 쉬운 검색이 가능합니다.' },
          { tab: '아파트 매물 정보 검색', content: '아파트 이름 등으로 검색하면 해당 아파트에 대한 상세 정보를 알 수 있습니다.' },
          { tab: '게시판', content: '게시판을 통해 다양한 정보를 얻거나, 정보를 제공할 수 있습니다.' },
          { tab: '정보 수정', content: '회원 가입된 정보를 수정하거나 삭제할 수 있습니다.' },
        ],
      }
    },
  }
</script>
<style>
/* Helper classes */
.basil {
  background-color: #5c6bc0 !important;
}
.basil--text {
  color: #356859 !important;
}
</style>

