<template>
  <div class="container">
    <div v-if="items.length">
      <br><br><br>
      <h2 style="font-family : 'Black Han Sans'">게시판 글 목록 </h2>
      <table class="table table-striped">
        <colgroup>
          <col :style="{ width: '5%' }" />
          <col :style="{ width: '50%' }" />
          <col :style="{ width: '10%' }" />
          <col :style="{ width: '25%' }" />
        </colgroup>
        <tr>
          <th>No</th>
          <th>Title</th>
          <th>Writer</th>
          <th>Date</th>
        </tr>
        <list-row
          v-for="(item, index) in items"
          :key="`${index}_items`"
          :no="item.no"
          :title="item.title"
          :writer="item.writer"
          :regtime="item.regtime"
        />
      </table>
    </div>
    <div v-else>등록된 공지가 없습니다.</div>
    <div class="text-right">
      <button class="btn" @click="movePage" style = "background-color : #5c6bc0; color : white" >등록</button>
    </div>
  </div>
</template>

<script>
import http from '@/util/http-common';
import ListRow from '@/components/Row.vue';
export default {
  name: 'list',
  components: {
    ListRow,
  },
  data: function() {
    return {
      items: [],
    };
  },
  created() {
    http
      .get('/board')
      .then(({ data }) => {
        this.items = data;
      })
      .catch(() => {
        alert('에러가 발생했습니다.');
      });
  },
  methods: {
    movePage() {
      this.$router.push('/create');
    },
  },
};
</script>

<style>
  .container{
    height : 65vh;
  }
</style>
