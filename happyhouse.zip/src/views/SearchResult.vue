<template>
    <div>
        <!-- <filtering-component></filtering-component> -->
        <map-component></map-component>
    </div>
</template>

<script>

import MapComponent from '../components/MapComponent';
// import FilteringComponent from '../components/FilteringComponent';
export default {
    components : {
        MapComponent,
        // "filtering-component" : FilteringComponent,
    }
}
</script>

<style>

</style>