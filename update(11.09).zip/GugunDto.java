package com.ssafy.happyhouse.model;

public class GugunDto {

	private String gugunCode;
	private String gugunName;
	
	protected String getGugunCode() {
		return gugunCode;
	}
	protected void setGugunCode(String gugunCode) {
		this.gugunCode = gugunCode;
	}
	protected String getGugunName() {
		return gugunName;
	}
	protected void setGugunName(String gugunName) {
		this.gugunName = gugunName;
	}
	
	
}
