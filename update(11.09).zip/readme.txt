20.11.09 업데이트 항목

목차
-----------------------------------
- 첨부 자료 항목
- 변경 사항
- 설정 방법
-----------------------------------

첨부 자료 항목
1. DB ERD
2. DB query
3. Spring Mapper (house.xml)
4. Spring Dto (sido.dto, gugun.dto)

DB 변경사항
1. revert location table. 
기존 DB는 sidocode, guguncode, dongcode 테이블을 location이라는 하나의 테이블로 합쳤으나
그 결과 구와 동 정보를 담고 있는 서울시 자료만 볼 수 있었습니다.
=> 원래 구조를 그대로 유지해 다른 시도 선택할 수 있게 하였습니다. 다만 아직까지 구와 동 정보는 DB에 없으므로 볼 수 없습니다.

2. create table member, interest-area
회원 정보와 각 회원의 관심 정보를 저장할 수 있는 테이블을 생성하였습니다.
=> 관심지역에 관한 컬럼은 추후 추가 예정

3. remove foreign keys
기존 DB는 테이블 정규화를 통해 각 테이블 간 관계를 설정하였으나, forward engineering 시 문제가 발생해
현재 foreign keys를 임시적으로 제거하였습니다.
=> 추후 재설정 필요

4. chage housedeal.code, houseinfo.code
기존 DB의 housedeal과 houseinfo는 code가 시,구,동 정보가 아니라 구 정보만 가지고 있어서 차후 모든 지역의 정보를 DB화할 때 문제가 발생할 수 있습니다.
또한 그로 인해 검색 시 code를 이용하지 못하고, 동 이름으로 검색하여 중복된 동 이름이 있는 경우 검색 결과를 제대로 가져오지 못하였습니다.
=> code를 전체 시,구,동 정보를 담은 코드로 업데이트하였습니다.
=> 주의 사항
4번 항목에서 Update시 10000개 당 1분 정도의 시간이 걸립니다. 따라서 중간에 connection error 또는 transaction error가 발생해 부득이 쿼리 실행 갯수를 분리하였습니다.


변경 사항 설정 방법
1. 첨부된 Dto와 mapper를 제 위치에 넣어줍니다.
2. 주어진 쿼리문을 실행합니다.
3. 유닛테스트를 합니다.

