import vue from "vue";

export const EventBus = new Vue();